CARA MENJALANKAN
1. Ekstrak ZIP.
2. Buka folder website_jasa_udi_lengkap.
3. Klik dua kali index.html.
4. Website berjalan tanpa XAMPP, Laragon, atau database.

FILE:
- index.html = struktur halaman
- style.css = desain dan tampilan
- script.js = jam, tanggal, chatbot, dan form WhatsApp
- README.txt = panduan

Catatan: chatbot yang tersedia adalah simulasi lokal. AI WhatsApp sungguhan membutuhkan WhatsApp Business API, server, dan layanan AI.
